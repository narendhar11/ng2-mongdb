export interface Property {
    id: number;
    ptitle: string;
    pdescription: string;
    imageurl: string;
    location: string;
    cost: number;
    bedrooms: number;
    bathrooms: number;
    yards: number;
    ptype: string;
  }