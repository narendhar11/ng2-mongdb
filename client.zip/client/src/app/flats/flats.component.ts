import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flats',
  templateUrl: './flats.component.html',
  styleUrls: ['./flats.component.css']
})
export class FlatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
