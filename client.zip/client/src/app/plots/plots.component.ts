import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plots',
  templateUrl: './plots.component.html',
  styleUrls: ['./plots.component.css']
})
export class PlotsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
